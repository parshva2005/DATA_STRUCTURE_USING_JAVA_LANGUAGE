import java.util.Scanner;

public class LinearSearch{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.print("\nENTER THE SIZE OF THE ARRAY : ");
        int n = sc.nextInt();

        int index = -1;
        index = linearSearch(n);
        if(index == -1){
            System.out.print("\nGIVEN NUMBER NOT FOUND");
        }
        else{
            System.out.print("\nGIVEN NUMBER FOUND AT INDEX "+index);
        }
    }

    public static int linearSearch(int n){
        Scanner sc = new Scanner(System.in);
        int[] arr = new int[n];
        for(int i= 0 ; i < n ; i++){
            System.out.print("\nENTER ELEMENT "+i + " : ");
            arr[i] = sc.nextInt();
        }

        System.out.print("\nENTER THE NUMBER TO SEARCH : ");
        int number = sc.nextInt();

        for(int i = 0 ; i < n ; i++){
            if(arr[i] == number){
                return i;
            }
        }

        return -1; 
    }
}
