import java.util.Scanner;
public class BinarySearch{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.print("\nENTER THE SIZE OF THE ARRAY : ");
        int n = sc.nextInt();

        int index = -1;
        index = BinarySearch(n);
        if(index == -1){
            System.out.print("\nGIVEN NUMBER NOT FOUND");
        }
        else{
            System.out.print("\nGIVEN NUMBER FOUND AT INDEX "+index);
        }
    }

    public static int BinarySearch(int n){
        Scanner sc = new Scanner(System.in);
        int[] arr = new int[n];
        for(int i= 0 ; i < n ; i++){
            System.out.print("\nENTER ELEMENT "+i + " : ");
            arr[i] = sc.nextInt();
        }

        System.out.print("\nENTER THE NUMBER TO SEARCH : ");
        int number = sc.nextInt();

        int left = 0;
        int right = n-1;
        
        while(left <= right){
            int middle = (left + right) / 2;

            if(arr[middle] == number){
                return middle;
            }
            else if(number < arr[middle]){
                right = middle - 1;
            }
            else{
                left = middle + 1;
            }
        }
        return -1; 
    }
}
