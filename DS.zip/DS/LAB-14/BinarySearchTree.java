import java.util.*;
public class BinarySearchTree {
    //Create a main method
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BST bst = new BST(); 
        int data ;

    }
}
//Create method for tree
class BST{
    public Node root = null;
    public Node temp = null;
    //Insertion method
    public void InsertNode(int data){
        Node NewNode = new Node(data);
        if(root == null){
            root = NewNode;
            return;
        }else if(data < root.info){
            temp = root;
            if(temp.Lptr == null && temp.Rptr == null){
                temp.Lptr = NewNode;
            }
            while(temp != null){
                if(temp.info < data ){
                    temp = temp
                }
            }
        }
    }
}

//Create a Node class
class Node{
    //Create a Node 
    int info;
    Node Lptr;
    Node Rptr;
    Node(int data){
        this.info = data;
        this.Lptr = null;
        this.Rptr = null;
    }
}