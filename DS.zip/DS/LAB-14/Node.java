import java.util.*;
public class BinarySearchTree {
    public static void main(String[] args) {
        
    }
}
//Creat
public class Node{

}