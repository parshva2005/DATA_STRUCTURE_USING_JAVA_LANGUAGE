import java.util.*;
public class CirculerLL {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Circuler cl = new Circuler();
        int data;
        while(true){
            System.out.println("SELECT OPTION : ");
            System.out.println("OPTION 1 TO INSERT AT FIRST VALUE  ");
            System.out.println("OPTION 2 TO INSERT AT LAST VALUE  ");
            System.out.println("OPTION 3 TO DELETE  ");
            System.out.println("OPTION 4 TO DISPLAY VALUE  ");
            System.out.print("OPTION 5 TO EXIT : ");
            int a = sc.nextInt();
            switch(a) {
                case 1:System.out.print("ENTER A NUMBER : ");
                    data = sc.nextInt();
                    cl.insertAtFirst(data);
                    break;
                case 2: System.out.print("ENTER A NUMBER : ");
                    data = sc.nextInt();
                    cl.insertAtLast(data);
                    break;
                case 3:System.out.print("ENTER A NUMBER : ");
                    data = sc.nextInt();
                    cl.Delete(data);
                    break;
                case 4: cl.Display();
                    break;
                case 5: return;
                default: System.out.println("INVALID OPTION ");
            }
        }
    }
}
class node{
    int info;
    node link;
    public node(int data) {
        this.info = data;
        this.link =null;
    }
}
class Circuler{
    public node first = null;
    public node last = first;
    public void insertAtFirst(int data) {
        node newNode=new node(data);
        if(first==null){
            first=newNode;
            last=first;
            first.link=last;
            return;
        }
        newNode.link =first;
        first = newNode;
        last.link = first;
    }
    public void insertAtLast(int data) {
        node newNode=new node(data);
        if(first==last){
            first.link = newNode;
            last = last.link;
            last.link = first;
        }else{
            last.link = newNode;
            newNode.link = first;
            last = last.link;
        }
    }
    public void Delete(int data){
        int count = 0;
        node temp = first;
        
        if(count==0){
            System.out.println("NO NODE FOUND");
        }else{
            System.out.println("NODE DELETED");
        }
        System.out.println();
    }
    public void Display(){
        node temp = first;
        while (temp.link != first) {
            System.out.print(temp.info+" , ");
            temp = temp.link;
        }
        System.out.print(temp.info+" , ");
        System.out.println();
        System.out.println();
    }
}