import java.util.*;
public class DoubLL {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Double dbl = new Double();
        int data;
        while(true){
            System.out.println("SELECT OPTION : ");
            System.out.println("OPTION 1 TO INSERT AT FIRST VALUE  ");
            System.out.println("OPTION 2 TO INSERT AT LAST VALUE  ");
            System.out.println("OPTION 3 TO DELETE  ");
            System.out.println("OPTION 4 TO DISPLAY VALUE  ");
            System.out.print("OPTION 5 TO EXIT : ");
            int a = sc.nextInt();
            switch(a) {
                case 1:System.out.print("ENTER A NUMBER : ");
                    data = sc.nextInt();
                    dbl.insertAtFirst(data);
                    break;
                case 2: System.out.print("ENTER A NUMBER : ");
                    data = sc.nextInt();
                    dbl.insertAtLast(data);
                    break;
                case 3:System.out.print("ENTER A NUMBER : ");
                    data = sc.nextInt();
                    dbl.Delete(data);
                    break;
                case 4: dbl.Display();
                    break;
                case 5: return;
                default: System.out.println("INVALID OPTION ");
            }
        }
    }
}
class node{
    int info;
    node Ll;
    node Rl;
    public node(int data) {
        this.info = data;
        this.Ll =null;
        this.Rl = null;
    }
}
class Double{
    public node first = null;
    public void insertAtFirst(int data) {
        node newNode=new node(data);
        if(first == null){
            first = newNode;
        }else{
            newNode.Rl = first;
            first.Ll = newNode;
            first = newNode;
        }
    }
    public void insertAtLast(int data) {
        node newNode=new node(data);
        if(first == null){
            first = newNode;
        }else{
            node temp = first;
            while(temp != null){
                temp = temp.Rl;
            }
            temp.Rl=newNode;
            newNode.Ll=temp;
        }
    }
    public void Delete(int data){
        
    }
    public void Display(){
        node temp = first;
        while (temp.link != first) {
            System.out.print(temp.info+" , ");
            temp = temp.link;
        }
        System.out.print(temp.info+" , ");
        System.out.println();
        System.out.println();
    }
}