import java.util.*;
public class RadixSort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER YOUR ARRAY SIZE : ");
        int n = sc.nextInt();
        int arr[] = new int[n];
        for(int i = 0; i < n; i++){
            System.out.println("ENTER YOUR ARRAY : ");
            arr[i] = sc.nextInt();
        }
        int arr2[] = new int[n];
        arr2 = Radix(arr);
        for(int i = 0; i < n; i++){
            System.out.print(arr2[i]+",");
        }
    }
    public static int[] Radix(int[] arr){
        int n = arr.length;
        int m = Highestele(arr);
        for(int exp = 1; m / exp > 0 ;exp *= 10 ){
            Counting(arr, n, exp);
        }
        return arr;
    }
    public static void Counting(int[] arr, int n, int exp){
        int output[] = new int[n];
        int count[] = new int[10];
        Arrays.fill(count, 0);

        for (int i = 0; i < n; i++) {
            count[(arr[i] / exp) % 10]++;
        }

        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }

        for (int i = n - 1; i >= 0; i--) {
            output[count[(arr[i] / exp) % 10] - 1] = arr[i];
            count[(arr[i] / exp) % 10]--;
        }

        for (int i = 0; i < n; i++) {
            arr[i] = output[i];
        }
    }
    public static int Highestele(int[] arr){
        int j=arr[0];
        for(int i=0; i<arr.length; i++){
            if(j<arr[i]){
                j=arr[i];
            }
        }
        return j;
    }
}