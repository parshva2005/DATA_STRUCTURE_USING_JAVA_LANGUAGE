import java.util.*;

public class Demo{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int a;
        System.out.print("ENTER A NUMBER : ");
        a = sc.nextInt();
        int b = 0;
        int c = 1;
        System.out.print(b+" ");
        System.out.print(c+" ");
        int d;
        for(int i = 2;i<a;i++){
            d = (b+c);
            System.out.print(d+" ");
            b = c;
            c = d;
        }
    }
}