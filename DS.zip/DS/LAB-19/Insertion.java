import java.util.*;

public class Insertion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER YOUR ARRAY SIZE : ");
        int n = sc.nextInt();
        int arr[] = new int[n];
        for(int i = 0; i < n; i++){
            System.out.println("ENTER YOUR ARRAY : ");
            arr[i] = sc.nextInt();
        }
        int[] arr2 = new int[n];
        arr2 = InsertionSort(arr);
        for(int i = 0; i < n; i++){
            System.out.print(arr2[i]+",");
        }
    }
    public static int[] InsertionSort(int[] arr){
        int temp = 0;
        int j;
        for(int i = 1;i<arr.length;i++){
            temp = arr[i];
            j = i-1;
            while(j!=-1){
                if(temp>=arr[j]){
                    break;
                }else{
                    arr[j+1] = arr[j];
                }
                j--;
            }
            j++;
            arr[j] = temp;
        }
        return arr;
    }
}
