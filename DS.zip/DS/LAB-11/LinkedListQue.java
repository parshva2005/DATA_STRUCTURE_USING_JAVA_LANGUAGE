import java.util.*;
class node{
    int info;
    node link;
    public node(int data) {
        this.info = data;
        this.link =null;
    }
}
class LinkedListNew{
    public node first=null;
    public node temp;
    public node pre;
    node newNode;
    public void Push(int data) {
        newNode=new node(data);
        newNode.link =first;
        first = newNode;
    }
    public void Pop(){
   		if(first.link==null){
            System.out.println("NOW LINKED LIST IS EMPTY ");
        }
        else{
            temp = first;
            while(temp.link!=null){
                pre = temp;
                temp=temp.link;
            }
            pre.link = null;
        }
   	}
    public void Display(){
        temp = first;
        while (temp != null) {
            System.out.println(temp.info);
            temp = temp.link;
        }
    }
}
public class LinkedListQue{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        LinkedListNew obj = new LinkedListNew();
        int data;
        while(true){
            System.out.println("SELECT OPTION : ");
            System.out.println("OPTION 1 TO PUSH VALUE : ");
            /*System.out.println("OPTION 2 TO PUSH AT LAST VALUE : ");*/
            /*System.out.println("OPTION 3 TO INSERT IN ORDERED LIST : ");*/
            System.out.println("OPTION 2 TO POP : ");
            System.out.println("OPTION 3 TO DISPLAY VALUE : ");
            System.out.print("OPTION 4 TO EXIT : ");
            int a = sc.nextInt();
            if(a==1){
                System.out.print("ENTER A NUMBER : ");
                data = sc.nextInt();
                obj.Push(data);
            }
            /*else if(a==2){
                System.out.print("ENTER A NUMBER : ");
                data = sc.nextInt();
                obj.PushAtLast(data);
            }*/
            /*else if(a==3){
                System.out.print("ENTER A NUMBER : ");
                data = sc.nextInt();
                obj.insertOrder(data);
            }*/
            else if(a==2){
                obj.Pop();
            }
            else if(a==3){
                obj.Display();
            }
            else if(a==4){
                break;
            }
            else{
                System.out.println("INVALID OPTION ");
            }
        }
	}
}