import java.util.*;
public class CirculerQueue {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER YOUR ARRAY SIZE : ");
        int n = sc.nextInt();
        QueueMethod CQM = new QueueMethod(n);
        int a;
        int data;
        while(true) {
            System.out.println("SELECT A CHOICE ");
            System.out.println("OPTION 1 FOR INSERT A DATA ");
            System.out.println("OPTION 2 FOR DELETE A DATA ");
            System.out.println("OPTION 3 FOR DISPLAY A DATA ");
            System.out.println("OPTION 4 FOR EXIT : ");
            a=sc.nextInt();
            switch(a) {
                case 1 : System.out.println("ENTER YOUR DATA : ");
                    data = sc.nextInt();
                    CQM.Enqueue(data);
                    break;
                case 2 : CQM.Dequeue(); 
                    break; 
                case 3 : CQM.Display(); 
                    break;
                case 4 : return;
                default : System.out.println("INVALID DATA");
            }
            System.out.println();
        }
    }
}
class QueueMethod{
	int r=-1;
    int f=-1;
	int arr[];
    QueueMethod(int n){
        arr = new int[n];
    }
    public void Enqueue(int data){
        if(r==arr.length-1 && f==0){
            System.out.println("QUEUE IS OVERFLOW ");
            return;
        }else if(r+1==f){
            System.out.println("QUEUE IS OVERFLOW ");
            return;
        }else if(r==arr.length-1){
            r = 0;
            arr[r]=data;
            r++;
        }else{
            r++;
            arr[r]=data;
            if(f==-1){
                f++;
            }
        }
    }
    public void Dequeue(){
        if(f==-1){
            System.out.println("QUEUE IS UNDERFLOW");
            return;
        }else if(f==arr.length-1 && r!=f){
            System.out.println(arr[f]+" IS DELETED");
            f=0;
        }else{
            System.out.println(arr[f]+" IS DELETED");
            if(f==r){ 
                r=-1;
                f=-1;
                return;
            }
            f++;
        }
    }
    public void Display(){
        System.out.println("YOUR QUEUE : ");
        for(int i=f;i<=r;i++){
            if(i==arr.length-1 && i!=r){
                i=0;
            }
            System.out.println(arr[i]);
        }
    }
}