import java.util.*;

public class MergeSorting {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER YOUR ARRAY SIZE : ");
        int n = sc.nextInt();
        int arr[] = new int[n];
        for(int i = 0; i < n; i++){
            System.out.println("ENTER YOUR ARRAY : ");
            arr[i] = sc.nextInt();
        }
        int arr2[] = new int[n];
        arr2 = MergeSort(0,arr.length-1,arr);
        for(int i = 0; i < n; i++){
            System.out.print(arr2[i]+",");
        }
    }
    public static int[] MergeSort(int low , int high , int[] arr){
        int mid = 0;
        if(low<high){
            mid = (high+low)/2;
            MergeSort(low,mid,arr);
            MergeSort(mid+1,high,arr);
            Merge(low,mid,high,arr);
        }
        return arr;
    }
    public static void Merge(int low , int mid , int high , int[] arr){
        int h = low;
        int i = low;
        int j = mid+1;
        int k;
        int[] b = new int[high+1];
        while(h<=mid && j<=high){
            if(arr[h] <= arr[j]){
                b[i] = arr[h];
                h++;
            }else{
                b[i] = arr[j];
                j++;
            }
            i++;
        }
        if(h>mid){
            for(k=j;k<=high;k++){
                b[i] = arr[k];
                i++;
            }
        }else{
            for(k=h;k<=mid;k++){
                b[i] = arr[k];
                i++;
            }
        }
        for(k=low;k<=high;k++){
            arr[k] = b[k];
        }
    }
}