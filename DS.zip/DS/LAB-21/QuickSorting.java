import java.util.*;

public class QuickSorting{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER YOUR ARRAY SIZE : ");
        int n = sc.nextInt();
        int arr[] = new int[n];
        for(int i = 0; i < n; i++){
            System.out.println("ENTER YOUR ARRAY : ");
            arr[i] = sc.nextInt();
        }
        int arr2[] = new int[n];
        arr2 = Quick(arr);
        for(int i = 0; i < n; i++){
            System.out.print(arr2[i]+",");
        }
    }
    public static int[] Quick(int[] arr){
        return arr;
    }
}