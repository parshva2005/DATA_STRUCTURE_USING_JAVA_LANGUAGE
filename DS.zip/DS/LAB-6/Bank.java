import java.util.*;
class Bank_Account{
	Scanner sc = new Scanner(System.in);
	int act_no;
	double balance;
	String act_name;
	void Act_Detail(){
		System.out.print("ENTER AN ACCOUNT NUMBER : ");
		act_no = sc.nextInt();
		System.out.print("ENTER AN ACCOUNT HOLDER NAME : ");
		act_name = sc.next();
		System.out.print("ENTER AN ACCOUNT HOLDER BALANCE : ");
		balance = sc.nextDouble();
	}
	int Num(){
		return act_no;
	}
	void Deposit(){
		System.out.print("ENTER YOUR DEPOSIT AMMOUNT : ");
		int dep = sc.nextInt();
		this.balance+=dep;
		System.out.println("ACCOUNT HOLDER NUMBER : "+this.act_no);
		System.out.println("ACCOUNT HOLDER NAME : "+this.act_name);
		System.out.println("ACCOUNT HOLDER BALANCE : "+this.balance);
	}
	void WithDraw(){
		System.out.print("ENTER YOUR WITHDRAW AMMOUNT : ");
		int widr = sc.nextInt();
		this.balance-=widr;
		System.out.println("ACCOUNT HOLDER NUMBER : "+this.act_no);
		System.out.println("ACCOUNT HOLDER NAME : "+this.act_name);
		System.out.println("ACCOUNT HOLDER BALANCE : "+this.balance);
	}
	void CheckBalance(){
		System.out.println("ACCOUNT HOLDER NUMBER : "+this.act_no);
		System.out.println("ACCOUNT HOLDER NAME : "+this.act_name);
		System.out.println("ACCOUNT HOLDER BALANCE : "+this.balance);
	}
}
public class Bank{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Bank_Account Bank_Detail[] = new Bank_Account[3];
		for (int i=0;i<3 ;i++ ) {
			System.out.println("----"+(i+1)+" ACCOUNT------");
			Bank_Detail[i] = new Bank_Account();
			Bank_Detail[i].Act_Detail();
		}
		System.out.println("--------------------");
		int index =0;
		int num;
		while(true){
			System.out.print("ENTER AN ACCOUNT HOLDER NUMBER : ");
			int number = sc.nextInt();
			for (int i=0;i<3 ;i++ ) {
				num =Bank_Detail[i].Num(); 
				if(number==num){
					index = i;
					break;
				}
			}
			if(index==0){
				System.out.print("INVALID ACCOUNT NUMBER ");
			}
			System.out.println("CHOOSE ANY OPTION WHICH YOU WANT : ");
			System.out.println("OPTION 1 TO DEPOSIT MONEY ");
			System.out.println("OPTION 2 TO WITHDRAW MONEY ");
			System.out.println("OPTION 3 TO CHECK BALANCE ");
			System.out.println("OPTION 0 TO Exit");
			System.out.print(" : ");
			int opt = sc.nextInt();
			if(opt==1){
				Bank_Detail[index].Deposit();
			}
			else if(opt==2){
				Bank_Detail[index].WithDraw();
			}
			else if(opt==3){
				Bank_Detail[index].CheckBalance();
			}
			else if(opt==0){
				break;
			}
			else{
				System.out.print("INVALID OPTION");
			}

		}
	}
}