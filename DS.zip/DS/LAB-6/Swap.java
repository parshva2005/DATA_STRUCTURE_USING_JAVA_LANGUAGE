import java.util.*;
public class Swap{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("ENTER A NUMBER 1 : ");
		int a = sc.nextInt();
		System.out.print("ENTER A NUMBER 2 : ");
		int b = sc.nextInt();
		int c = b;
		b=SwapNum(a,b);
		a=SwapNum(c,b);
		System.out.print(a+" "+b);
	}
	static int SwapNum(int n,int temp){
		temp=n;
		return temp;
	}
}