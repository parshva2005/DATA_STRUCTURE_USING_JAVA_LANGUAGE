import java.util.*;
class Temp_Convert{
	Scanner sc = new Scanner(System.in);
	double celsius;
	double fahrenhit;
	String unit;
	void S_Temp(){
		System.out.print("ENTER A TEMPERATURE UNIT : ");
		unit = sc.next();
		if(unit.toLowerCase().equals("celsius")){
			System.out.print("ENTER A TEMPERATURE IN CELSIUS : ");
			celsius = sc.nextDouble();
		}
		else{
			System.out.print("ENTER A TEMPERATURE IN FAHRENHIT : ");
			fahrenhit = sc.nextDouble();
		}
	}
	void P_Temp(){
		if(this.unit.toLowerCase().equals("celsius")){
			fahrenhit=(this.celsius*(9/5))+32;
			System.out.print(fahrenhit);
		}
		else{
			celsius=(this.fahrenhit-32)*(5/9);
			System.out.print(celsius);
		}
	}
}
public class TempConvert{
	public static void main(String[] args) {
		Temp_Convert Convert = new Temp_Convert();
		Convert.S_Temp();
		Convert.P_Temp();
	}
}