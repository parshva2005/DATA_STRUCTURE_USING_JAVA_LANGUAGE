import java.util.*;
class Student_Detail{
	int enrollment_no;
	String name;
	int semester;
	double cpi;
	void Detail(){
		Scanner sc = new Scanner(System.in);
		System.out.print("ENTER A STUDENT ENROLLMENT NO. : ");
		enrollment_no = sc.nextInt();
		System.out.print("ENTER A STUDENT NAME : ");
		name = sc.next();
		System.out.print("ENTER A STUDENT SEMESTER : ");
		semester = sc.nextInt();
		System.out.print("ENTER A STUDENT CPI : ");
		cpi = sc.nextDouble();
	}
	void P_Detail(){
		System.out.println(this.enrollment_no);
		System.out.println(this.name);
		System.out.println(this.semester);
		System.out.println(this.cpi);
	}
}
public class Student{
	public static void main(String[] args) {
		Student_Detail S_Detail[] = new Student_Detail[5];
		for(int i=0;i<5;i++){
			S_Detail[i]=new Student_Detail();
			S_Detail[i].Detail();
		}
		for (int i=0;i<5 ;i++ ) {
			S_Detail[i].P_Detail();	
		}
		
	}
}