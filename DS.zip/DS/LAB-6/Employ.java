import java.util.*;
class Employ_Detail{
	Scanner sc = new Scanner(System.in);
	int employ_id;
	String name;
	String designation;
	double salary;
	void Detail(){
		System.out.print("ENTER AN EMPLOY ID : ");
		employ_id = sc.nextInt();
		System.out.print("ENTER AN EMPLOY NAME : ");
		name = sc.next();
		System.out.print("ENTER AN EMPLOY DESIGNATION : ");
		designation = sc.next();
		System.out.print("ENTER AN EMPLOY SALARY : ");
		salary = sc.nextDouble();
	}
	void P_Detail(){
		System.out.println(this.employ_id);
		System.out.println(this.name);
		System.out.println(this.designation);
		System.out.println(this.salary);
	}

}
public class Employ{
	public static void main(String[] args) {
		Employ_Detail E_detail = new Employ_Detail();
		E_detail.Detail();
		E_detail.P_Detail();
	}
}