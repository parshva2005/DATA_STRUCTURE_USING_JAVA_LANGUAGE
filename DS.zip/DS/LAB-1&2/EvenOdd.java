import java.util.*;
public class EvenOdd{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		if(a%2==0){
			System.out.print("EVEN NUMBER");
		}
		else{
			System.out.print("ODD NUMBER");
		}
	}
}