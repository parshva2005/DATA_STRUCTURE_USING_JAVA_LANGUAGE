import java.lang.*;
import java.util.*;
public class Areaofcircle{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double r = sc.nextDouble();
		double a =0;
		a = (Math.PI)*r*r;
		System.out.print(a);
	}
}