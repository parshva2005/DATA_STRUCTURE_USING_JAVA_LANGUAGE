import java.lang.reflect.Array;
import java.util.*;

public class ShellSort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER YOUR ARRAY SIZE : ");
        int n = sc.nextInt();
        int arr[] = new int[n];
        for(int i = 0; i < n; i++){
            System.out.println("ENTER YOUR ARRAY : ");
            arr[i] = sc.nextInt();
        }
        int arr2[] = new int[n];
        arr2 = Shell(arr);
        for(int i = 0; i < n; i++){
            System.out.print(arr2[i]+",");
        }
    }
    public static int[] Shell(int[] arr){
        for(int gap = arr.length/2 ; gap >= 1 ; gap /= 2){
            for(int i = gap ; i < arr.length ; i++){
                for(int j = i-gap ; j >= 0 ; j -= gap){
                    if(arr[j+gap] > arr[j])
                        break;
                    else{
                        int temp = arr[j+gap];
                        arr[j+gap] = arr[j];
                        arr[j] = temp;
                    }
                        
                }
            }
        }
        return arr;
    }
}
