import java.util.*;

class stack{
	char[] s ;
	int n;
	int top=-1;
	String temppolish = "";
	int rank=0;
	char temp;
	stack(int n){
		this.n = n;
		s = new char[n];
	}
	public int F(char Ipf){
		switch(Ipf){
			case '+': return 2;
			case '-' : return 2;
			case '*' : return 4;
			case '/' : return 4;
			case '^' : return 5;
			case '(' : return 9;
			case ')' : return 0;
			default : return 7;
		}
	}
	public int G(char Spf){
		switch(Spf){
			case '+': return 1;
			case '-' : return 1;
			case '*' : return 3;
			case '/' : return 3;
			case '^' : return 6;
			case '(' : return 0;
			default : return 8;
		}
	}
	public void push(char x){
        if(top>n){
            System.out.println("STACK IS OVERFLOW");
            return ;
        }else{
            top++;
            s[top]=x;
        }
    }
    public char pop(){
        if(top<0){
            System.out.println("STACK UNDERFLOW");
            return 0;
        }else{
            top--;
            return s[top+1];
        }
    }
    public void next(char next){
    	if(top<0){
    		System.out.println("INVALID");
			return ;
    	}else if(next==')'){
    		while(s[top]!='('){
    			temp = pop();
	    		temppolish+=temp;
	    		rank--;
    		}
    		pop();
    	}else if(F(next)==7){
    		temppolish+=next;
    		rank++;
    	}else if(G(s[top])>F(next)){
    		while(G(s[top])>F(next)){
    			temp = pop();
	    		temppolish+=temp;
	    		rank--;
    		}
    		push(next);
    	}else{
    		push(next);
    	}
    } 
}

public class InfixToPrefix{
	public static void main(String[] args) {
		String polish = "";
		char a ;
		Scanner sc = new Scanner(System.in);
		System.out.print("ENTER A YOUR STRING : ");
		String infix = sc.next();
		stack st = new stack(infix.length());
		st.push('(');
		for(int i=infix.length()-1;i>=0;i--){
			if(infix.charAt(i)=='('){
				st.next(')');
			}
			else if(infix.charAt(i)==')'){
				st.next('(');
			}
			else{
				st.next(infix.charAt(i));
			}
		}
		st.next(')');
		for(int i=st.temppolish.length()-1;i>=0;i--){
			polish += st.temppolish.charAt(i);
		}
		System.out.print("PREFIX : "+polish);
	}
}