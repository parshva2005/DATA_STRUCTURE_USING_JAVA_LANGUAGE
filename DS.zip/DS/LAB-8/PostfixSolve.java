import java.util.*;
public class PostfixSolve {
    public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("ENTER A YOUR STRING : ");
		String infix = sc.next();
		infix+=')';
		stack st = new stack();
        st.stacklength(infix.length());
		st.push('(');
		for(int i=0;i<infix.length();i++){
			st.next(infix.charAt(i));
		}
		String polish = st.polish;
		String ans = postToSolve(polish);
		System.out.println(ans);
	}
	public static String postToSolve(String polish){
		int temp1;
		int temp2;
		stack st = new stack();
		for(int i=0;i<polish.length();i++){
			if(st.F(polish.charAt(i))==7){
				st.push(polish.charAt(i));
			}else{
				temp1 = st.pop();
				temp2 = st.pop();
				if(polish.charAt(i)=='+'){
					st.push((char)(temp2+temp1));
				}else if(polish.charAt(i)=='-'){
					st.push((char)(temp2-temp1));
				}else if(polish.charAt(i)=='/'){
					st.push((char)(temp2/temp1));
				}else if(polish.charAt(i)=='*'){
					st.push((char)(temp2*temp1));
				}else{
					st.push((char)(temp2^temp1));
				}
			}
		}
		if(st.top==0){
			int ans = st.pop();
			String str = "YOUR ANSWER IS : "+ans;
			return str;
		}else{
			String str = "CANT EVELUATE YOUR EXPRESSION ";
			return str;
		}
	}
}
class stack{
	char[] s ;
	int n;
	int top=-1;
	String polish = "";
	int rank=0;
	char temp;
    int ans = 0;
	public void stacklength(int n){
		this.n = n;
		s = new char[n];
	}
	public int F(char Ipf){
		switch(Ipf){
			case '+': return 1;
			case '-' : return 1;
			case '*' : return 3;
			case '/' : return 3;
			case '^' : return 6;
			case '(' : return 9;
			case ')' : return 0;
			default : return 7;
		}
	}
	public int G(char Spf){
		switch(Spf){
			case '+': return 2;
			case '-' : return 2;
			case '*' : return 4;
			case '/' : return 4;
			case '^' : return 5;
			case '(' : return 0;
			default : return 8;
		}
	}
	public void push(char x){
        if(top>n){
            System.out.println("STACK IS OVERFLOW");
            return ;
        }else{
            top++;
            s[top]=x;
        }
    }
    public char pop(){
        if(top<0){
            System.out.println("STACK UNDERFLOW");
            return 0;
        }else{
            top--;
            return s[top+1];
        }
    }
    public void next(char next){
    	if(top<0){
    		System.out.println("INVALID");
    	}else if(next==')'){
    		while(s[top]!='('){
    			temp = pop();
	    		polish+=temp;
	    		rank--;
    		}
    		pop();
    	}else if(F(next)==7){
    		polish+=next;
    		rank++;
    	}else if(G(s[top])>=F(next)){
    		if(s[top]=='^' && next=='^'){
    			push(next);
    		}else{
    			while(G(s[top])>=F(next)){
    				temp = pop();
	    			polish+=temp;
	    			rank--;
    			}
    			push(next);
    		}
    	}else{
    		push(next);
    	}
    } 
}
