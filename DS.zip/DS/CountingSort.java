import java.util.*;

public class CountingSort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER YOUR ARRAY SIZE : ");
        int n = sc.nextInt();
        int arr[] = new int[n];
        for(int i = 0; i < n; i++){
            System.out.println("ENTER YOUR ARRAY : ");
            arr[i] = sc.nextInt();
        }
        int arr2[] = new int[n];
        arr2 = Counting(arr);
        for(int i = 0; i < n; i++){
            System.out.print(arr2[i]+",");
        }
    }
    public static int[] Counting(int[] arr){
        int h = Highestele(arr);
        int[] arr2 = new int[h+1];
        for(int i=0;i<arr.length;i++){
            arr2[arr[i]]++;
        }
        int k = 0;
        for(int i=0;i<arr2.length;i++){
            while(arr2[i]!=0){
                arr[k] = i;
                k++;
                arr2[i]--;
            }
        }
        return arr;
    }
    public static int Highestele(int[] arr){
        int j=0;
        for(int i=0; i<arr.length; i++){
            if(j<arr[i]){
                j=arr[i];
            }
        }
        return j;
    }
}
