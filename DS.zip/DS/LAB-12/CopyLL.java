import java.util.*;
public class CopyLL {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedListNew obj = new LinkedListNew();
        int data;
        while(true){
            System.out.println("SELECT OPTION : ");
            System.out.println("OPTION 1 TO INSERT AT FIRST VALUE : ");
            System.out.println("OPTION 2 TO INSERT AT LAST VALUE : ");
            System.out.println("OPTION 3 TO INSERT IN ORDERED LIST : ");
            System.out.println("OPTION 4 TO DELETE FIRST : ");
            System.out.println("OPTION 5 TO DELETE LAST : ");
            System.out.println("OPTION 6 TO DISPLAY VALUE : ");
            System.out.print("OPTION 7 TO EXIT : ");
            int a = sc.nextInt();
            switch(a) {
                case 1:System.out.print("ENTER A NUMBER : ");
                    data = sc.nextInt();
                    obj.insertAtFirst(data);
                    break;
                case 2:System.out.print("ENTER A NUMBER : ");
                    data = sc.nextInt();
                    obj.insertAtLast(data);
                    break;
                case 3:System.out.print("ENTER A NUMBER : ");
                    data = sc.nextInt();
                    obj.insertOrder(data);
                    break;
                case 4: obj.deleteFirst();
                    break;
                case 5: obj.deleteLast();
                    break;
                case 6: obj.Display();
                    break;
                case 7: return;
                default: System.out.println("INVALID OPTION ");
            }
        } 
    }
}
class node{
    int info;
    node link;
    public node(int data) {
        this.info = data;
        this.link =null;
    }
}
class LinkedListNew{
    public node first=null;
    public node temp;
    public node pre;
    public node save;
    public node begin;
    node newNode;
    public void insertAtFirst(int data) {
        newNode=new node(data);
        newNode.link =first;
        first = newNode;
    }
    public void insertAtLast(int data) {
        newNode=new node(data);
        temp = first;
        while(temp.link != null){
            temp = temp.link;
        }
        temp.link = newNode;
    }
    public void insertOrder(int data){
        newNode = new node(data);
        if(first==null){
            newNode.link = null;
            first=newNode;
        }else{
            temp = first;
            while(temp.link!=null && temp.link.info<=newNode.info){
                temp = temp.link;
            }
            if(temp.link==null){
                temp.link = newNode;
            }else{
                newNode.link = temp.link;
                temp.link = newNode;
            }
        }
    }
    public void deleteFirst(){
        temp=first;
        first=first.link;
        temp.link=null;
    }
    public void deleteLast(){
        if(first.link==null){
            System.out.println("NOW LINKED LIST IS EMPTY ");
        }else{
            temp = first;
            while(temp.link!=null){
                pre = temp;
                temp=temp.link;
            }
            pre.link = null;
        }
    }
    public void Display(){
        temp = first;
        while (temp != null) {
            System.out.print(temp.info+" , ");
            temp = temp.link;
        }
        System.out.println();
        Copy();
    }
    public void Copy(){
        if(first == null){
            System.out.println("EMPTY LINKED LIST ");
            return ;
        }else{
            newNode = new node(first.info);
            begin = newNode;
            save = first;
            while(save.link != null){
                pre = newNode;
                save = save.link;
                newNode = new node(save.info);
                pre.link = newNode;
            }
            temp = begin;
            System.out.println("COPY LINKED LIST : ");
            while(temp != null){
                System.out.print(temp.info+" , ");
                temp = temp.link;
            }
            System.out.println();
        }
    }
}