import java.util.*;
class RecoStr{
    Scanner sc = new Scanner(System.in);
    int top = -1 ;
    char[] a;
    int n;
    int i;
    RecoStr(int n){
        this.n = n;
        a = new char[n];
    }
    public void push(char x){
        if(top>n){
            System.out.println("STACK IS OVERFLOW");
        }
        else{
            top++;
            a[top]=x;
        }
    }
    public int pop(){
        if(top<0){
            System.out.println("STACK UNDERFLOW");
            return 0;
        }
        else{
            top--;
            return a[top+1];
        }
    }
    public void display(){
        for(i=0;i<=a.length;i++){
           System.out.print(a[i]+" "); 
        }
    }
}
public class StackRecoStr {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = new String();
        System.out.println("ENTER YOUR STRING : ");
        str = sc.next();
        RecoStr reco = new RecoStr(str.length());
        reco.push('c');
        int i=0;
        while(str.charAt(i)=='c'){
            if(str.charAt(i)==' '){
                System.out.print("INVALID STRING");
            }else{
                reco.push(str.charAt(i));
                i++;    
            } 
        }
    }
}