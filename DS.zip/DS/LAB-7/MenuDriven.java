import java.util.*;
import java.lang.*;
class Stack{
	Scanner sc = new Scanner(System.in);
	int n=0;
	int top=-1;
	int arr[];
	int k=0;
	Stack(){
		System.out.print("ENTER A SIZE OF STACK : ");
		n=sc.nextInt();
		arr= new int[n];
	}
	public void push(int x){
		if(this.top>this.n){
			System.out.println("STACK IS OVERFLOW");
		}
		else{
			this.top++;
			this.arr[this.top]=x;
			k++;
		}
	}
	public int pop(){
		if(this.top<0){
			System.out.println("STACK UNDERFLOW");
			return 0;
		}
		else{
			this.top--;
			k--;
			return this.arr[this.top+1];
		}
	}
	public int peep(int i){
		if((this.top-i+1)<0){
			System.out.println("INVALID INDEX");
			return 0;
		}
		else{
			return this.arr[this.top-i+1];
		}
	}	
	public void change(int i,int x){
		if((this.top-i+1)<0){
			System.out.println("INVALID INDEX");
		}
		else{
			this.arr[this.top-i+1]=x;
		}
	}
	public void display(){
		for(int j=0;j<	k;j++){
			System.out.print(this.arr[j]+" , ");
		}
		System.out.println();
	}
}
public class MenuDriven{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Stack stack1 = new Stack();
		try{
			while(true){
				System.out.println("CHOOSE YOUR OPTION : ");
				System.out.println("OPTION 1 FOR PUSH AN ELEMENT");
				System.out.println("OPTION 2 FOR POP AN ELEMENT");
				System.out.println("OPTION 3 FOR PEEP AN ELEMENT");
				System.out.println("OPTION 4 FOR CHANGE AN ELEMENT");
				System.out.println("OPTION 5 FOR DISPLAY AN ELEMENT");
				System.out.println("OPTION 6 FOR EXIT");
				int opt = sc.nextInt();
				int x=0;
				int i=0;
				int print=0;
				if(opt==1){
					System.out.print("ENTER A YOUR NUMBER : ");
					x=sc.nextInt();
					stack1.push(x);
				}
				else if(opt==2){
					print = stack1.pop();
					System.out.println("YOUR POP ELEMENT IS : "+print);
				}
				else if(opt==3){
					System.out.print("ENTER AN INDEX : ");
					i=sc.nextInt();
					print = stack1.peep(i);
					System.out.println("YOUR PEEP ELEMENT IS : "+print);
				}
				else if(opt==4){
					System.out.print("ENTER AN INDEX : ");
					i=sc.nextInt();
					System.out.print("ENTER A YOUR NUMBER : ");
					x=sc.nextInt();
					stack1.change(i,x);
				}
				else if(opt==5){
					stack1.display();
				}
				else if(opt==6){
					break;
				}
				else{
					System.out.println("INVALID OPTION");
				}
			}	
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}