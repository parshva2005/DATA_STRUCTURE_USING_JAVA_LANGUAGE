import java.util.Scanner;

public class CheckStringPattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string to check:");
        String input = sc.next();
        if (isValidPattern(input)) {
            System.out.println("The string is at valid form.");
        } else {
            System.out.println("The string is at invalid form.");
        }
    }
    public static boolean isValidPattern(String input) {
        if (input == null ) {
            return false;
        }
        int countA = 0;
        int countB = 0;
        boolean foundB = false;
        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) == 'a') {
                if (foundB) {
                    return false;
                }
                countA++;
            } else if (input.charAt(i) == 'b') {
                foundB = true;
                countB++;
            } else {
                return false;
            }
        }
        return countA == countB && countA > 0;
    }
}
