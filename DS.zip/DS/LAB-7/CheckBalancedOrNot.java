import java.util.*;
import java.util.Stack;
public class CheckBalancedOrNot {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter No of Test Cases:");
        int T = sc.nextInt();
        sc.nextLine();
        for (int i = 0; i < T; i++) {
            System.out.println("Enter test case string:");
            String input = sc.next();
            int result = isBalanced(input);
            System.out.println(result);
        }
    }
    public static int isBalanced(String str) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == '(' || str.charAt(i) == '{' || str.charAt(i) == '[') {
                stack.push(str.charAt(i));
            }else if (str.charAt(i) == ')' || str.charAt(i) == '}' || str.charAt(i) == ']') {
                if (stack.isEmpty()) {
                    return 0;
                }
                char open = stack.pop();
                if ((str.charAt(i) == ')' && open != '(') ||
                    (str.charAt(i) == '}' && open != '{') ||
                    (str.charAt(i) == ']' && open != '[')) {
                    return 0;
                }
            }
        }
        return stack.isEmpty() ? 1 : 0;
    }
}